<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
use Elementor\Controls_Manager;

class My_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'custom-post-widget';
    }

    public function get_title() {
        return __( 'Custom Post Widget', 'my-elementor-widget' );
    }

    public function get_icon() {
        return 'eicon-post-list'; // Use Elementor's default icon or upload your custom icon
    }

    public function get_categories() {
        return [ 'general' ]; // The widget's category. You can use existing categories or create a new one
    }

     public function __construct($data = [], $args = null) {
        parent::__construct($data, $args);

        // Include necessary scripts/styles
        //add_action('elementor/element/custom_post_widget/section_custom_css/after_section_end', [$this, 'register_controls_script']);
        //add_action('elementor/frontend/after_enqueue_styles', [$this, 'enqueue_widget_styles']);
        wp_enqueue_style('slick-min-styles', 'https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.css', [], null);
        wp_enqueue_style('slick-theme-styles', 'https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick-theme.min.css', [], null);
        wp_enqueue_style('your-widget-styles', plugin_dir_url(__DIR__) . 'css/your-widget-styles.css', [], null);

        wp_enqueue_script('your-widget-slick-js', 'https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js', ['jquery'], null, true);
        wp_enqueue_script('your-widget-control-js', plugin_dir_url(__DIR__) . 'js/your-widget-control.js', ['jquery'], null, true);
        
    }

    // public function register_controls_script($widget) {
    //     wp_enqueue_script('your-widget-control-js', plugin_dir_url(__DIR__) . 'js/your-widget-control.js', ['jquery'], null, true);
    // }

    // public function enqueue_widget_styles() {
    //     wp_enqueue_style('your-widget-styles', plugin_dir_url(__DIR__) . 'css/your-widget-styles.css', [], null);
    // }

    protected function _register_controls() {
        // Add widget controls here

        //Tab Content
        $this->start_controls_section(
            'setting_section',
            [
                'label' => esc_html__( 'Setting', 'textdomain' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'post_type_select',
            [
                'label'       => __('Select Post Type', 'your-text-domain'),
                'type'        => \Elementor\Controls_Manager::SELECT,
                'options'     => $this->get_registered_post_types(),
                'default' => 'post',
            ]
        );

        $this->add_control(
            'select_display_type',
            [
                'type' => \Elementor\Controls_Manager::SELECT,
                'label' => esc_html__( 'Select Display Type', 'textdomain' ),
                'options' => [
                    'default' => esc_html__( 'Default', 'textdomain' ),
                    'listing' => esc_html__( 'Listing', 'textdomain' ),
                    'slider' => esc_html__( 'Slider', 'textdomain' ),
                ],
                'default' => 'listing',
            ]
        );

        $this->add_control(
            'posts_per_page',
            [
                'label'       => __('Posts Per Page', 'your-text-domain'),
                'type'        => \Elementor\Controls_Manager::SELECT,
                'options'     => $this->get_posts_per_page_options(),
                'default'     => 10, // Default value
            ]
        );

        $this->add_control(
            'custom_posts_per_page',
            [
                'label'       => __('Custom Posts Per Page', 'your-text-domain'),
                'type'        => \Elementor\Controls_Manager::NUMBER,
                'default'     => 5,
                'condition'   => [
                    'posts_per_page' => 'custom',
                ],
                'description' => __('Enter the number of posts per page.', 'your-text-domain'),
            ]
        );

        $this->add_control(
            'post_column',
            [
                'label'       => __('Post Column', 'your-text-domain'),
                'type'        => \Elementor\Controls_Manager::SELECT,
                'options'     => $this->get_posts_column_options(),
                'default'     => 2, // Default value
            ]
        );

        $this->add_control(
            'orderby',
            [
                'label'       => __('Orderby', 'your-text-domain'),
                'type'        => \Elementor\Controls_Manager::SELECT,
                'options'     => $this->get_posts_orderby_options(),
                'default'     => 'date', // Default value
            ]
        );

        $this->add_control(
            'order',
            [
                'label'       => __('Order', 'your-text-domain'),
                'type'        => \Elementor\Controls_Manager::SELECT,
                'options'     => $this->get_posts_order_options(),
                'default'     => 'DESC', // Default value
            ]
        );

        $this->end_controls_section();
        //End Tab Content


        //Tab Post Setting 
        $this->start_controls_section(
            'post_setting',
            [
                'label' => esc_html__( 'Post Setting', 'textdomain' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'show_title',
            [
                'label' => __('Show Title', 'your-text-domain'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'your-text-domain'),
                'label_off' => __('Hide', 'your-text-domain'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'title_link',
            [
                'label' => __('Title Link', 'your-text-domain'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'your-text-domain'),
                'label_off' => __('No', 'your-text-domain'),
                'return_value' => 'yes',
                'default' => 'yes',
                'condition'   => [
                    'show_title' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'show_future_images',
            [
                'label' => __('Show Future Image', 'your-text-domain'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'your-text-domain'),
                'label_off' => __('Hide', 'your-text-domain'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'show_future_image_after_title',
            [
                'label' => __('Show future image after title', 'your-text-domain'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'your-text-domain'),
                'label_off' => __('No', 'your-text-domain'),
                'return_value' => 'yes',
                'default' => 'no',
                'condition'   => [
                    'show_future_images' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'show_excerpt',
            [
                'label' => __('Show Excerpt', 'your-text-domain'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'your-text-domain'),
                'label_off' => __('Hide', 'your-text-domain'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_control(
            'show_read_more_button',
            [
                'label' => __('Read More Button', 'your-text-domain'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'your-text-domain'),
                'label_off' => __('Hide', 'your-text-domain'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_control(
            'button_text',
            [
                'label' => __('Button Text', 'your-text-domain'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Read More',
                'condition'   => [
                    'show_read_more_button' => 'yes',
                ],
            ]
        );

        // $this->add_control(
        //     'selected_posts',
        //     [
        //         'label' => __( 'Select Posts', 'your-text-domain' ),
        //         'type' => \Elementor\Controls_Manager::SELECT2,
        //         'options' => $this->get_posts_options(),
        //         'multiple' => true,
        //         'label_block' => true,
        //     ]
        // );

        $this->end_controls_section();
        //End Tab Post Setting

        //Tab Post display structure
        $this->start_controls_section(
            'display_structure',
            [
                'label' => esc_html__( 'Post display structure', 'textdomain' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'post_structure',
            [
                'label' => __('Post Custom Structure', 'your-text-domain'),
                'description' => __('Create post display structure with using fields #Title#, #Link#, #FutureImage#, #Excerpt#, #ReadMoreButton# ', 'your-text-domain'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => '',
                
            ]
        );

        $this->end_controls_section();
        //End Tab Post display structure

    }

    protected function get_registered_post_types() {
        $post_types = get_post_types(['public' => true], 'objects');
        $options = [];
        foreach ($post_types as $post_type) {
            if($post_type->name != 'page' && $post_type->name != 'attachment' && $post_type->name != 'elementor_library' && $post_type->name != 'e-landing-page' ){
                $options[$post_type->name] = $post_type->label;
            }
        }
        return $options;
    }

    protected function get_posts_per_page_options() {
        $options = [];
        // Define your preferred options
        $options['5'] = __('5', 'your-text-domain');
        $options['10'] = __('10', 'your-text-domain');
        $options['15'] = __('15', 'your-text-domain');
        $options['20'] = __('20', 'your-text-domain');
        $options['-1'] = __('-1', 'your-text-domain');
        $options['custom'] = __('Custom', 'your-text-domain');
        return $options;
    }

    protected function get_posts_column_options() {
        $options = [];
        // Define your preferred options
        $options['1'] = __('1', 'your-text-domain');
        $options['2'] = __('2', 'your-text-domain');
        $options['3'] = __('3', 'your-text-domain');
        $options['4'] = __('4', 'your-text-domain');
        $options['5'] = __('5', 'your-text-domain');
        return $options;
    }

    protected function get_posts_orderby_options() {
        $options = [];
        // Define your preferred options
        $options['date'] = __('Date', 'your-text-domain');
        $options['title'] = __('Title', 'your-text-domain');
        $options['name'] = __('Name', 'your-text-domain');
        
        return $options;
    }

    protected function get_posts_order_options() {
        $options = [];
        // Define your preferred options
        $options['DESC'] = __('DESC', 'your-text-domain');
        $options['ASC'] = __('ASC', 'your-text-domain');
        
        return $options;
    }

    

    // protected function get_posts_options() {
    //     $args = array(
    //         'post_type'      => 'post',
    //         'posts_per_page' => -1,
    //     );

    //     $posts = get_posts( $args );
    //     $options = array();

    //     foreach ( $posts as $post ) {

    //         $options[ $post->ID ] = $post->post_title;
    //     }

    //     return $options;
    // }

    
    protected function render() {

        // Output widget HTML here
        $settings = $this->get_settings_for_display();
        $post_type = $settings['post_type_select'];
        $select_display_type = $settings['select_display_type'];
        $posts_per_page = $settings['posts_per_page'];
        $custom_posts_per_page = $settings['custom_posts_per_page'];
        $post_column = $settings['post_column'];
        $orderby = $settings['orderby'];
        $order = $settings['order'];

        $show_title = $settings['show_title'];
        $title_link = $settings['title_link'];
        $show_future_images = $settings['show_future_images'];
        $show_future_image_after_title = $settings['show_future_image_after_title'];
        $show_excerpt = $settings['show_excerpt'];
        $show_read_more_button = $settings['show_read_more_button'];
        $button_text = $settings['button_text'];

        $post_structure = $settings['post_structure'];
        
        if($posts_per_page == 'custom'){
            $posts_per_page = $custom_posts_per_page;
        }

        $args = array(
            'post_type' => $post_type,
            'post_status' => 'publish',
            'posts_per_page' => $posts_per_page,
            'orderby' => $orderby,
            'order' => $order,
        );
        
        $the_query = new WP_Query( $args );
        if ( $the_query->have_posts() ) { ?>

            <div class="custom-post-wrapper post-<?=$post_type?> column-<?=$post_column?>" id="<?php if ('slider' === $select_display_type) : echo "custom-post-slider"; endif;?>">
                <?php
                while ( $the_query->have_posts() ) {

                    $the_query->the_post();

                    $id=get_the_ID();
                    $feat_image=get_the_post_thumbnail_url($id);
                    $title=get_the_title($id);
                    $excerpt=get_the_excerpt($id);
                    $link=get_the_permalink($id);
                    
                    if(!empty($post_structure)){
                        $structure = str_replace("#FutureImage#", $feat_image, $post_structure);
                        $structure = str_replace("#Link#", $link, $structure);
                        $structure = str_replace("#Title#", $title, $structure);
                        $structure = str_replace("#Excerpt#", $excerpt, $structure);
                        $structure = str_replace("#ReadMoreButton#", $button_text, $structure);
                        echo $structure;
                    }else{
                        ?>
                        <div class="post-item">
                            <?php if ('yes' === $show_future_images) : ?>
                                <img class="item-img" src="<?=$feat_image?>">
                            <?php endif; ?>
                            <div class="item-content-wrap">
                                <?php 
                                if('yes' === $show_title) : 
                                    if ('yes' === $title_link) : ?>
                                        <h4 class="item-title"><a href="<?=$link?>"><?=$title?></a></h4>
                                        <?php 
                                    else : ?>
                                        <h4 class="item-title"><?=$title?></h4>
                                        <?php 
                                    endif;  
                                endif; 

                                if ('yes' === $show_excerpt) : ?>
                                    <div class="item-excerpt"><?=$excerpt?></div>
                                    <?php 
                                endif; 
                                if ('yes' === $show_read_more_button) : ?>
                                    <a class="read-more" href="<?=$link?>"><?=$button_text?></a>
                                    <?php 
                                endif; ?>
                            </div>
                        </div>
                        <?php
                    }
                }
                wp_reset_postdata();
                ?>
            </div>
            <?php
        }

        ?>
        <script>
        jQuery(document).ready(function($) {
            // Initialize Slick slider
            $('#custom-post-slider').slick({
                // Add your Slick slider settings here
                slidesToShow: 3,
                slidesToScroll: 1,
                autoplay: true,
                autoplaySpeed: 2000,
            });
        });
        </script>
        <?php
    }

    protected function _content_template() {
        // Output widget template content here
    }
}

?>