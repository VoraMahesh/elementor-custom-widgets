<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
use Elementor\Controls_Manager;

class My_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'custom-button-widget';
    }

    public function get_title() {
        return __( 'Custom Button Widget', 'my-elementor-widgets' );
    }

    public function get_icon() {
        return 'eicon-button'; // Use Elementor's default icon or upload your custom icon
    }

    public function get_categories() {
        return [ 'general' ]; // The widget's category. You can use existing categories or create a new one
    }

     public function __construct($data = [], $args = null) {
        parent::__construct($data, $args);

        // Include necessary scripts/styles
        wp_enqueue_style('custom-button-widget-styles', plugin_dir_url(__DIR__) . 'css/custom-button-widget-styles.css', [], null);    
    }


    protected function _register_controls() {

        // Content Section
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Content', 'my-elementor-widgets'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'button_text',
            [
                'label' => __('Button Text', 'my-elementor-widgets'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Click me', 'my-elementor-widgets'),
                'placeholder' => __('Enter your text', 'my-elementor-widgets'),
            ]
        );

        $this->add_control(
            'button_link',
            [
                'label' => __('Link', 'my-elementor-widgets'),
                'type' => \Elementor\Controls_Manager::URL,
                'placeholder' => __('https://your-link.com', 'my-elementor-widgets'),
                'show_external' => true,
                'default' => [
                    'url' => '',
                    'is_external' => false,
                    'nofollow' => false,
                ],
            ]
        );

        $this->add_control(
            'button_icon',
            [
                'label' => __('Button Icon', 'my-elementor-widgets'),
                'type' => \Elementor\Controls_Manager::MEDIA,
                // 'default' => [
                //     'url' => \Elementor\Utils::get_placeholder_image_src(),
                // ],
            ]
        );

        $this->end_controls_section();

        // Style Section
        $this->start_controls_section(
            'style_section',
            [
                'label' => __('Button Style', 'my-elementor-widgets'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'button_color',
            [
                'label' => __('Text Color', 'my-elementor-widgets'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ft_button' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_background_color',
            [
                'label' => __('Background Color', 'my-elementor-widgets'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ft_button' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'hover_background_color',
            [
                'label' => __('Hover Background Color', 'my-elementor-widgets'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ft_button::before' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
        'icon_background_color',
            [
                'label' => __('Icon Background Color', 'my-elementor-widgets'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ft_button .icon' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'button_icon_width',
            [
                'label' => __('Icon Image Width', 'my-elementor-widgets'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'default' => [
                    'unit' => 'px',
                    'size' => 16, // Set your default width here
                ],
                'selectors' => [
                    '{{WRAPPER}} .ft_button .icon img' => 'width: {{SIZE}}{{UNIT}};',
                ],
                'range' => [
                    'px' => [
                        'min' => 10,
                        'max' => 100,
                    ],
                    '%' => [
                        'min' => 10,
                        'max' => 100,
                    ],
                ],
            ]
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'button_typography',
                'label' => __('Typography', 'my-elementor-widgets'),
                'selector' => '{{WRAPPER}} .ft_button',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'button_border',
                'label' => __('Border', 'my-elementor-widgets'),
                'selector' => '{{WRAPPER}} .ft_button',
            ]
        );
        $this->add_responsive_control(
            'button_border_radius',
            [
                'label' => __('Border Radius', 'my-elementor-widgets'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .ft_button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .ft_button::before' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'button_padding',
            [
                'label' => __('Padding', 'my-elementor-widgets'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .ft_button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();

        $this->add_render_attribute('button', 'class', 'ft_button');
        $this->add_render_attribute('button', 'href', esc_url($settings['button_link']['url']));

        if ($settings['button_link']['is_external']) {
            $this->add_render_attribute('button', 'target', '_blank');
        }

        if ($settings['button_link']['nofollow']) {
            $this->add_render_attribute('button', 'rel', 'nofollow');
        }
        ?>
        
        <a <?php echo $this->get_render_attribute_string('button'); ?>>
            <?php echo esc_html($settings['button_text']); 
            if (!empty($settings['button_icon']['url'])) { ?>
                <span class="icon"><img src="<?=$settings['button_icon']['url']?>" alt="<?php echo esc_attr($settings['button_text']); ?>"></span>
                <?php
            }
            ?>
        </a>
        <?php
    }

    protected function _content_template() {
        ?>
        <# var link = settings.button_link.url ? 'href="' + settings.button_link.url + '"' : ''; #>
        <a class="ft_button" {{{ link }}} >
            {{{ settings.button_text }}}

            <# if ( settings.button_icon.url ) { #>
                <span class="icon"><img src="{{ settings.button_icon.url }}" alt="{{ settings.button_text }}"></span>
            <# } #>
        </a>
        <?php
    }
}

?>