<?php
/*
Plugin Name: Elementor Custom Widgets
Description: Custom elementor widget for button and testimonials.
Version: 1.0.0
Author: Mahesh Vora
Author URI: https://developer.wordpress.org/
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// Define plugin constants
define( 'MY_ELEMENTOR_WIDGET__FILE__', __FILE__ );
define( 'MY_ELEMENTOR_WIDGET__DIR__', __DIR__ );

// Include the main plugin file
require_once MY_ELEMENTOR_WIDGET__DIR__ . '/widget-plugin.php';

?>