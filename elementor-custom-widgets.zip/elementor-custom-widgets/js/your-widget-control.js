//jQuery(document).ready(function(){

	console.log("test js");

	// jQuery('#custom-post-slider').slick({
	// 	slidesToShow: 3,
	//   	slidesToScroll: 1,
	//   	autoplay: true,
	//   	autoplaySpeed: 3000,
	//   	// speed: 8000,
	//   	pauseOnHover: true,
	//   	// cssEase: 'linear'
	// });

//});