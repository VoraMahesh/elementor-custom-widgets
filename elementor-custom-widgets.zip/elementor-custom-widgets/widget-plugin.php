<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

final class My_Elementor_Widget {

    const VERSION = '1.0.0';

    private static $_instance = null;

    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    public function __construct() {
        add_action( 'elementor/widgets/widgets_registered', [ $this, 'init_widgets' ] );
    }

    public function init_widgets() {
        // Require the widget file
        //require_once MY_ELEMENTOR_WIDGET__DIR__ . '/widgets/custom-post-widget.php';
        require_once MY_ELEMENTOR_WIDGET__DIR__ . '/widgets/custom-button-widget.php';

        // Register the widget
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new My_Widget() );
        
    }
}

// Instantiate the plugin
My_Elementor_Widget::instance();

?>