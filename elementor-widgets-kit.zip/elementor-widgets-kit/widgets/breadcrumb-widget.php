<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Custom_Breadcrumb_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'custom_breadcrumb';
    }

    public function get_title() {
        return __( 'Breadcrumb', 'custom-elementor' );
    }

    public function get_icon() {
        return 'eicon-posts-ticker';
    }

    public function get_categories() {
        return [ 'general' ];
    }

    public function __construct($data = [], $args = null) {
        parent::__construct($data, $args);

        // Include necessary scripts/styles
        wp_enqueue_style('breadcrumb-widget-styles', plugin_dir_url(__DIR__) . 'css/breadcrumb-widget-styles.css', [], null);
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section_breadcrumb',
            [
                'label' => __( 'Breadcrumb', 'custom-elementor' ),
            ]
        );

        $repeater = new \Elementor\Repeater();

        // Page Name Control
        $repeater->add_control(
            'breadcrumb_name',
            [
                'label' => __( 'Page Name', 'custom-elementor' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Page Name', 'custom-elementor' ),
                'label_block' => true,
            ]
        );

        // Page URL Control
        $repeater->add_control(
            'breadcrumb_url',
            [
                'label' => __( 'Page URL', 'custom-elementor' ),
                'type' => \Elementor\Controls_Manager::URL,
                'placeholder' => __( 'https://your-link.com', 'custom-elementor' ),
                'show_external' => true,
                'default' => [
                    'url' => '',
                    'is_external' => false,
                    'nofollow' => false,
                ],
            ]
        );

        // Add the repeater to the widget
        $this->add_control(
            'breadcrumb_list',
            [
                'label' => __( 'Breadcrumb Items', 'custom-elementor' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'breadcrumb_name' => __( 'Home', 'custom-elementor' ),
                        'breadcrumb_url' => [
                            'url' => home_url(),
                        ],
                    ],
                ],
                'title_field' => '{{{ breadcrumb_name }}}',
            ]
        );

        $this->end_controls_section();
    }

    // Rendering the breadcrumb HTML with custom fields
    protected function render() {
        $settings = $this->get_settings_for_display();

        if ( ! empty( $settings['breadcrumb_list'] ) ) {
            echo '<div class="breadcrumb-wrap">';
            $breadcrumbs = array();
            // Loop through each breadcrumb item
            foreach ($settings['breadcrumb_list'] as $index => $breadcrumb) {
                if ($breadcrumb) {
                    $page_title = $breadcrumb['breadcrumb_name'];
                    $page_url =  $breadcrumb['breadcrumb_url']['url'];

                    $breadcrumbs[] = array(
                        '@type' => 'ListItem',
                        'position' => $index+1, // Position starts from 2 since "Accueil" is at position 1
                        'name' => $page_title,
                        'item' => !empty($breadcrumb['breadcrumb_url']['url']) ? $breadcrumb['breadcrumb_url']['url'] : get_permalink()
                    );
                    
                    if(!empty($page_url)){ 
                        echo '<a href="'.esc_url($page_url).'">'.esc_html($page_title).'</a>';
                    }else{
                        echo esc_html($page_title);
                    }
        
                    // Display the separator if it's not the last breadcrumb
                    if ($index < count($settings['breadcrumb_list']) - 1) {
                        echo '<span class="separator"> > </span>';
                    }
                }
            }
            echo '</div>';

            // Output the Schema.org structured data script
            if (!empty($breadcrumbs)) {
                ?>
                <script type="application/ld+json">
                {
                    "@context": "https://schema.org",
                    "@type": "BreadcrumbList",
                    "itemListElement": <?php echo json_encode($breadcrumbs, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT); ?>
                }
                </script>
                <?php
            }
        }
    }

    protected function _content_template() {
        
    }
}