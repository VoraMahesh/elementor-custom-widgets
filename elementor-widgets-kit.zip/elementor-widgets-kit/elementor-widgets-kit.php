<?php

/**
 * Plugin Name: Elementor-Widgets-Kit
 * Description: Elementor Widgets
 * Version: 1.0.0
 * Author: Mahesh Vora
 * Author URI:  
 * Text Domain: Elementor-Widgets-Kit
 */


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// Check if Elementor is active and included
function register_custom_widgets() {
    // Make sure Elementor is activated
    if ( did_action( 'elementor/loaded' ) ) {
        add_action( 'elementor/widgets/widgets_registered', 'register_custom_widget' );
    }
}
add_action( 'plugins_loaded', 'register_custom_widgets' );

// Register the Breadcrumb Widget
function register_custom_widget() {
    require_once( __DIR__ . '/widgets/breadcrumb-widget.php' );
    \Elementor\Plugin::instance()->widgets_manager->register( new \Custom_Breadcrumb_Widget() );
}

